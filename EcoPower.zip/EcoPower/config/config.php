<?php

/**
 * Application Configuration
 * Global constants and settings for EcoPower AI
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Application settings
define('APP_NAME', 'EcoPower AI');
define('APP_VERSION', '1.0.0');
define('BASE_URL', 'http://localhost/EcoPower/');

// Security settings
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds

// Energy and environmental constants
// These are standard conversion factors for sustainability calculations

/**
 * Generator fuel consumption rate
 * Average: 0.3 liters per kWh for typical diesel generators
 */
define('FUEL_CONSUMPTION_PER_KWH', 0.3);

/**
 * CO2 emission factor for diesel fuel
 * Standard: 2.68 kg CO2 per liter of diesel burned
 * Source: EPA emission factors
 */
define('CO2_PER_LITER_DIESEL', 2.68);

/**
 * CO2 emission factor for Grid power
 * Average: 0.45 kg CO2 per kWh
 */
define('CO2_PER_KWH_GRID', 0.45);

/**
 * Energy source cost per kWh (in local currency)
 */
define('COST_GRID_PER_KWH', 0.15);
define('COST_SOLAR_PER_KWH', 0.05); // Amortized solar panel cost
define('COST_GENERATOR_PER_KWH', 0.35); // Fuel + maintenance

/**
 * AI prediction settings
 */
define('PREDICTION_CONFIDENCE_THRESHOLD', 70.0); // Minimum confidence percentage
define('ANOMALY_DETECTION_SIGMA', 2.0); // Standard deviations for anomaly detection
define('MOVING_AVERAGE_WINDOW', 7); // Days for moving average calculation
define('GEMINI_API_KEY', 'YOUR_API_KEY'); // Replace with your actual API key
define('GEMINI_API_ENDPOINT', 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent');

/**
 * Solar availability hours (typical for tropical regions)
 * Peak solar generation: 8 AM to 5 PM
 */
define('SOLAR_START_HOUR', 8);
define('SOLAR_END_HOUR', 17);
define('SOLAR_PEAK_START', 11);
define('SOLAR_PEAK_END', 14);

/**
 * Helper function to check if user is logged in
 */
function isLoggedIn()
{
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Helper function to get current user ID
 */
function getCurrentUserId()
{
    return $_SESSION['user_id'] ?? null;
}

/**
 * Helper function to check session timeout
 */
function checkSessionTimeout()
{
    if (isset($_SESSION['last_activity'])) {
        $elapsed = time() - $_SESSION['last_activity'];
        if ($elapsed > SESSION_TIMEOUT) {
            session_unset();
            session_destroy();
            return false;
        }
    }
    $_SESSION['last_activity'] = time();
    return true;
}

/**
 * Helper function to send JSON response
 */
function sendJsonResponse($success, $message, $data = null)
{
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

/**
 * Helper function to sanitize input
 */
function sanitizeInput($data)
{
    return htmlspecialchars(strip_tags(trim($data)));
}

/**
 * Helper function to validate email
 */
function isValidEmail($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

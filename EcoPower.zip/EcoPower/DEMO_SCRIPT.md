# EcoPower AI - Demo Video Script

**Title**: Optimizing for Impact: The EcoPower AI Story  
**Duration**: 3-5 Minutes  

---

## 🎬 Scene 1: The Problem (Intro)
**Visual**: Close-up of the Landing Page hero section. Slowly scroll down to the "Built for Energy-Constrained Regions" section.  
**Narrator**: "In many regions today, energy instability is a daily challenge. Families and small businesses rely heavily on expensive, high-emission generators to stay powered. But what if we could use intelligence to break this cycle?"  

## 🎬 Scene 2: Introducing EcoPower AI
**Visual**: Scroll through the 8-card Features Grid on the Homepage. Hover over "AI-Driven Analysis" and "Smart Recommendations."  
**Narrator**: "Welcome to EcoPower AI—an intelligent energy optimization platform designed to reduce fuel consumption and lower carbon footprints. Our system analyze your patterns to tell you exactly when to use grid power, when to switch to solar, and how to avoid the generator entirely."  

## 🎬 Scene 3: The Dashboard (Impact at a Glance)
**Visual**: Log in as 'ibrahim'. Show the Dashboard with its interactive charts and high-savings metrics.  
**Narrator**: "Meet Ibrahim, a small business owner. On his dashboard, Ibrahim see's his impact in real-time. Over 60.0 kg of CO₂ reduced and significant fuel savings—all verified through our data-driven engine."  

## 🎬 Scene 4: Analysis & AI Methodology
**Visual**: Navigate to the 'Analysis' page. Show the energy consumption daily averages and predictions chart. Scroll down to the 'Transparent AI Methodology'.  
**Narrator**: "How do we do it? EcoPower AI uses a hybrid model. We combine classic statistical forecasting—like moving averages and linear trends—with the advanced reasoning power of Google Gemini 2.5 Flash. This ensures every prediction isn't just a number, but a smart, explainable insight."  

## 🎬 Scene 5: Actionable Recommendations
**Visual**: Navigate to the 'Recommendations' page. Show the paginated list. Click 'Next' to demonstrate the 5-item-per-page navigation.  
**Narrator**: "Optimization is nothing without action. Our recommendations page provides a clear, prioritized checklist. Ibrahim gets hourly advice on the best energy source to use, helping him save cost and fuel with every switch. And with our new paginated view, even complex 24-hour schedules are easy to manage."  

## 🎬 Scene 6: Environmental Sustainability
**Visual**: Show the 'Impact Report' page. Highlight the "Real-World Equivalents" (trees planted / car km avoided).  
**Narrator**: "Beyond the wallet, we track the planet. EcoPower AI translates complex energy data into real-world impact. Every liter of fuel saved is a measurable step toward a sustainable future."  

## 🎬 Scene 7: Conclusion & Call to Action
**Visual**: Back to the Landing Page hero section.  
**Narrator**: "EcoPower AI isn't just a tool; it's a mission to empower energy-constrained regions through intelligence. Join us in optimizing for impact. EcoPower AI: Intelligent Energy. Sustainable Future."  

---

## 💡 Recording Tips for the User:
- **Pace**: Speak clearly and slowly. Give the viewer time to look at the UI.
- **Highlights**: Use a screen recording tool that highlights your cursor clicks.
- **Background**: Ensure your XAMPP server is running and your Gemini API key is active for 'Live' prediction demos!

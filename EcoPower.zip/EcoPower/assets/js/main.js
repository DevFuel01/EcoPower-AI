/**
 * EcoPower AI - Main JavaScript
 * Core utilities and API handlers
 */

// ============================================
// Configuration
// ============================================
const API_BASE = '/EcoPower/api';

// ============================================
// Session Management
// ============================================
function checkSession() {
    const user = getSessionUser();
    if (!user && !isPublicPage()) {
        window.location.href = 'login.html';
    }
    return user;
}

function getSessionUser() {
    const userStr = sessionStorage.getItem('ecopower_user');
    return userStr ? JSON.parse(userStr) : null;
}

function setSessionUser(user) {
    sessionStorage.setItem('ecopower_user', JSON.stringify(user));
}

function clearSession() {
    sessionStorage.removeItem('ecopower_user');
}

function isPublicPage() {
    const publicPages = ['index.html', 'login.html', 'register.html', ''];
    const currentPage = window.location.pathname.split('/').pop();
    return publicPages.includes(currentPage);
}

// ============================================
// API Request Handler
// ============================================
async function apiRequest(endpoint, method = 'GET', data = null) {
    const options = {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        }
    };

    if (data && method !== 'GET') {
        options.body = JSON.stringify(data);
    }

    try {
        const response = await fetch(API_BASE + endpoint, options);
        const result = await response.json();
        
        // Handle session expiration
        if (!result.success && result.message && result.message.includes('Session expired')) {
            clearSession();
            window.location.href = 'login.html';
            return null;
        }
        
        return result;
    } catch (error) {
        console.error('API Request Error:', error);
        showNotification('Network error. Please check your connection.', 'danger');
        return null;
    }
}

// ============================================
// Notification System
// ============================================
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existing = document.querySelector('.notification');
    if (existing) {
        existing.remove();
    }

    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification alert alert-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        max-width: 500px;
        animation: slideIn 0.3s ease-out;
    `;
    notification.textContent = message;

    // Add close button
    const closeBtn = document.createElement('span');
    closeBtn.innerHTML = '&times;';
    closeBtn.style.cssText = `
        float: right;
        font-size: 1.5rem;
        font-weight: bold;
        cursor: pointer;
        margin-left: 1rem;
    `;
    closeBtn.onclick = () => notification.remove();
    notification.insertBefore(closeBtn, notification.firstChild);

    document.body.appendChild(notification);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => notification.remove(), 300);
        }
    }, 5000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// ============================================
// Form Validation
// ============================================
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;

    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;

    inputs.forEach(input => {
        if (!input.value.trim()) {
            isValid = false;
            input.style.borderColor = 'var(--danger-color)';
        } else {
            input.style.borderColor = 'var(--border-color)';
        }

        // Email validation
        if (input.type === 'email' && input.value && !validateEmail(input.value)) {
            isValid = false;
            input.style.borderColor = 'var(--danger-color)';
        }
    });

    return isValid;
}

// ============================================
// Loading Indicator
// ============================================
function showLoading(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = '<div class="spinner"></div>';
}

function hideLoading(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const spinner = container.querySelector('.spinner');
    if (spinner) {
        spinner.remove();
    }
}

// ============================================
// Date/Time Formatting
// ============================================
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
    });
}

// ============================================
// Number Formatting
// ============================================
function formatNumber(number, decimals = 2) {
    return parseFloat(number).toFixed(decimals);
}

function formatCurrency(amount) {
    return '₦' + formatNumber(amount, 2);
}

// ============================================
// Energy Source Utilities
// ============================================
function getSourceColor(source) {
    const colors = {
        'solar': '#f39c12',
        'grid': '#3498db',
        'generator': '#e74c3c'
    };
    return colors[source] || '#95a5a6';
}

function getSourceIcon(source) {
    const icons = {
        'solar': '☀️',
        'grid': '⚡',
        'generator': '⚙️'
    };
    return icons[source] || '🔌';
}

function getPriorityBadge(priority) {
    const badges = {
        'high': 'badge-high',
        'medium': 'badge-medium',
        'low': 'badge-low'
    };
    return badges[priority] || 'badge-medium';
}

// ============================================
// User Profile Display
// ============================================
function updateUserProfile() {
    const user = getSessionUser();
    if (!user) return;

    const profileElements = document.querySelectorAll('.user-name');
    profileElements.forEach(el => {
        el.textContent = user.full_name || user.username;
    });

    const businessTypeElements = document.querySelectorAll('.business-type');
    businessTypeElements.forEach(el => {
        el.textContent = user.business_type === 'household' ? 'Household' : 'Small Business';
    });
}

// ============================================
// Logout Function
// ============================================
async function logout() {
    const result = await apiRequest('/auth/logout.php', 'POST');
    clearSession();
    window.location.href = 'index.html';
}

// ============================================
// Initialize on Page Load
// ============================================
document.addEventListener('DOMContentLoaded', function() {
    // Check session for protected pages
    if (!isPublicPage()) {
        const user = checkSession();
        if (user) {
            updateUserProfile();
        }
    }

    // Add logout handler to logout buttons
    const logoutBtns = document.querySelectorAll('.logout-btn');
    logoutBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    });
});

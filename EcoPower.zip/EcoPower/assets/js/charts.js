/**
 * EcoPower AI - Chart Visualization Library
 * Creates energy consumption and prediction charts using HTML5 Canvas
 */

// ============================================
// Line Chart for Energy Consumption
// ============================================
function createEnergyChart(canvasId, data, options = {}) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) {
        console.error('Canvas not found:', canvasId);
        return null;
    }

    const ctx = canvas.getContext('2d');
    const width = canvas.width = canvas.offsetWidth * 2; // Retina display
    const height = canvas.height = canvas.offsetHeight * 2;
    ctx.scale(2, 2);

    const displayWidth = width / 2;
    const displayHeight = height / 2;

    // Chart configuration
    const padding = { top: 40, right: 40, bottom: 60, left: 60 };
    const chartWidth = displayWidth - padding.left - padding.right;
    const chartHeight = displayHeight - padding.top - padding.bottom;

    // Clear canvas
    ctx.clearRect(0, 0, displayWidth, displayHeight);

    // Find data range
    const allValues = data.datasets.flatMap(d => d.data);
    const maxValue = Math.max(...allValues);
    const minValue = Math.min(...allValues);
    const valueRange = maxValue - minValue || 1;

    // Draw grid lines
    ctx.strokeStyle = '#e0e0e0';
    ctx.lineWidth = 1;
    const gridLines = 5;
    
    for (let i = 0; i <= gridLines; i++) {
        const y = padding.top + (chartHeight / gridLines) * i;
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + chartWidth, y);
        ctx.stroke();

        // Y-axis labels
        const value = maxValue - (valueRange / gridLines) * i;
        ctx.fillStyle = '#666';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(value.toFixed(1), padding.left - 10, y + 4);
    }

    // Draw X-axis labels
    const labelInterval = Math.ceil(data.labels.length / 10);
    data.labels.forEach((label, index) => {
        if (index % labelInterval === 0) {
            const x = padding.left + (chartWidth / (data.labels.length - 1)) * index;
            ctx.fillStyle = '#666';
            ctx.font = '12px sans-serif';
            ctx.textAlign = 'center';
            ctx.save();
            ctx.translate(x, displayHeight - padding.bottom + 20);
            ctx.rotate(-Math.PI / 4);
            ctx.fillText(label, 0, 0);
            ctx.restore();
        }
    });

    // Draw datasets
    data.datasets.forEach((dataset, datasetIndex) => {
        ctx.strokeStyle = dataset.color || '#3498db';
        ctx.fillStyle = dataset.color || '#3498db';
        ctx.lineWidth = 2;

        // Draw line
        ctx.beginPath();
        dataset.data.forEach((value, index) => {
            const x = padding.left + (chartWidth / (dataset.data.length - 1)) * index;
            const y = padding.top + chartHeight - ((value - minValue) / valueRange) * chartHeight;

            if (index === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        });
        ctx.stroke();

        // Draw points
        dataset.data.forEach((value, index) => {
            const x = padding.left + (chartWidth / (dataset.data.length - 1)) * index;
            const y = padding.top + chartHeight - ((value - minValue) / valueRange) * chartHeight;

            ctx.beginPath();
            ctx.arc(x, y, 4, 0, Math.PI * 2);
            ctx.fill();
        });

        // Draw area fill (optional)
        if (dataset.fill) {
            ctx.globalAlpha = 0.2;
            ctx.fillStyle = dataset.color || '#3498db';
            ctx.beginPath();
            dataset.data.forEach((value, index) => {
                const x = padding.left + (chartWidth / (dataset.data.length - 1)) * index;
                const y = padding.top + chartHeight - ((value - minValue) / valueRange) * chartHeight;

                if (index === 0) {
                    ctx.moveTo(x, padding.top + chartHeight);
                    ctx.lineTo(x, y);
                } else {
                    ctx.lineTo(x, y);
                }
            });
            ctx.lineTo(padding.left + chartWidth, padding.top + chartHeight);
            ctx.closePath();
            ctx.fill();
            ctx.globalAlpha = 1;
        }
    });

    // Draw legend
    let legendX = padding.left;
    const legendY = 20;
    data.datasets.forEach((dataset, index) => {
        // Color box
        ctx.fillStyle = dataset.color || '#3498db';
        ctx.fillRect(legendX, legendY - 8, 15, 15);

        // Label
        ctx.fillStyle = '#333';
        ctx.font = '14px sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(dataset.label, legendX + 20, legendY + 4);

        legendX += ctx.measureText(dataset.label).width + 50;
    });

    // Draw axis labels
    ctx.fillStyle = '#333';
    ctx.font = 'bold 14px sans-serif';
    ctx.textAlign = 'center';
    
    // Y-axis label
    ctx.save();
    ctx.translate(15, displayHeight / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(options.yLabel || 'Consumption (kWh)', 0, 0);
    ctx.restore();

    // X-axis label
    ctx.fillText(options.xLabel || 'Time', displayWidth / 2, displayHeight - 10);

    return canvas;
}

// ============================================
// Bar Chart for Energy Source Comparison
// ============================================
function createBarChart(canvasId, data, options = {}) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) {
        console.error('Canvas not found:', canvasId);
        return null;
    }

    const ctx = canvas.getContext('2d');
    const width = canvas.width = canvas.offsetWidth * 2;
    const height = canvas.height = canvas.offsetHeight * 2;
    ctx.scale(2, 2);

    const displayWidth = width / 2;
    const displayHeight = height / 2;

    const padding = { top: 40, right: 40, bottom: 60, left: 60 };
    const chartWidth = displayWidth - padding.left - padding.right;
    const chartHeight = displayHeight - padding.top - padding.bottom;

    ctx.clearRect(0, 0, displayWidth, displayHeight);

    const maxValue = Math.max(...data.values);
    const barWidth = chartWidth / data.labels.length - 20;
    const barSpacing = chartWidth / data.labels.length;

    // Draw grid lines
    ctx.strokeStyle = '#e0e0e0';
    ctx.lineWidth = 1;
    const gridLines = 5;
    
    for (let i = 0; i <= gridLines; i++) {
        const y = padding.top + (chartHeight / gridLines) * i;
        ctx.beginPath();
        ctx.moveTo(padding.left, y);
        ctx.lineTo(padding.left + chartWidth, y);
        ctx.stroke();

        // Y-axis labels
        const value = maxValue - (maxValue / gridLines) * i;
        ctx.fillStyle = '#666';
        ctx.font = '12px sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(value.toFixed(1), padding.left - 10, y + 4);
    }

    // Draw bars
    data.values.forEach((value, index) => {
        const x = padding.left + barSpacing * index + 10;
        const barHeight = (value / maxValue) * chartHeight;
        const y = padding.top + chartHeight - barHeight;

        // Bar
        ctx.fillStyle = data.colors[index] || '#3498db';
        ctx.fillRect(x, y, barWidth, barHeight);

        // Value label on top of bar
        ctx.fillStyle = '#333';
        ctx.font = 'bold 12px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(value.toFixed(1), x + barWidth / 2, y - 5);

        // X-axis label
        ctx.fillStyle = '#666';
        ctx.font = '12px sans-serif';
        ctx.fillText(data.labels[index], x + barWidth / 2, displayHeight - padding.bottom + 20);
    });

    // Draw title
    if (options.title) {
        ctx.fillStyle = '#333';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(options.title, displayWidth / 2, 20);
    }

    return canvas;
}

// ============================================
// Donut Chart for Energy Source Distribution
// ============================================
function createDonutChart(canvasId, data, options = {}) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) {
        console.error('Canvas not found:', canvasId);
        return null;
    }

    const ctx = canvas.getContext('2d');
    const width = canvas.width = canvas.offsetWidth * 2;
    const height = canvas.height = canvas.offsetHeight * 2;
    ctx.scale(2, 2);

    const displayWidth = width / 2;
    const displayHeight = height / 2;

    ctx.clearRect(0, 0, displayWidth, displayHeight);

    const centerX = displayWidth / 2;
    const centerY = displayHeight / 2;
    const radius = Math.min(displayWidth, displayHeight) / 2 - 60;
    const innerRadius = radius * 0.6;

    const total = data.values.reduce((sum, val) => sum + val, 0);
    let currentAngle = -Math.PI / 2;

    // Draw segments
    data.values.forEach((value, index) => {
        const sliceAngle = (value / total) * Math.PI * 2;

        // Draw slice
        ctx.fillStyle = data.colors[index] || '#3498db';
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, currentAngle, currentAngle + sliceAngle);
        ctx.arc(centerX, centerY, innerRadius, currentAngle + sliceAngle, currentAngle, true);
        ctx.closePath();
        ctx.fill();

        // Draw label
        const labelAngle = currentAngle + sliceAngle / 2;
        const labelX = centerX + Math.cos(labelAngle) * (radius + 30);
        const labelY = centerY + Math.sin(labelAngle) * (radius + 30);

        ctx.fillStyle = '#333';
        ctx.font = '12px sans-serif';
        ctx.textAlign = labelX > centerX ? 'left' : 'right';
        ctx.fillText(data.labels[index], labelX, labelY);

        // Draw percentage
        const percentage = ((value / total) * 100).toFixed(1) + '%';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText(percentage, labelX, labelY + 15);

        currentAngle += sliceAngle;
    });

    // Draw center circle
    ctx.fillStyle = '#fff';
    ctx.beginPath();
    ctx.arc(centerX, centerY, innerRadius, 0, Math.PI * 2);
    ctx.fill();

    // Draw center text
    if (options.centerText) {
        ctx.fillStyle = '#333';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(options.centerText, centerX, centerY);
    }

    return canvas;
}

// ============================================
// Progress Bar
// ============================================
function createProgressBar(containerId, value, max, options = {}) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const percentage = (value / max) * 100;
    const color = options.color || '#2c7a3f';

    container.innerHTML = `
        <div style="background-color: #e0e0e0; border-radius: 10px; overflow: hidden; height: 30px;">
            <div style="
                width: ${percentage}%;
                background-color: ${color};
                height: 100%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-weight: bold;
                transition: width 0.5s ease;
            ">
                ${percentage.toFixed(1)}%
            </div>
        </div>
        ${options.label ? `<div style="margin-top: 5px; font-size: 0.875rem; color: #666;">${options.label}</div>` : ''}
    `;
}

// ============================================
// Helper: Prepare Chart Data from API Response
// ============================================
function prepareEnergyChartData(energyData) {
    // 1. Get unique sorted timestamps
    const timestampSet = new Set(energyData.map(d => d.timestamp));
    const uniqueTimestamps = Array.from(timestampSet).sort();

    // 2. Create labels from timestamps
    const labels = uniqueTimestamps.map(ts => {
        const date = new Date(ts);
        return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    });

    // 3. Create datasets for each source
    const sources = ['solar', 'grid', 'generator'];
    const datasets = [];

    sources.forEach(source => {
        // Map values to the common timeline (fill 0 if no data for that timestamp)
        const dataMap = new Map();
        energyData
            .filter(d => d.energy_source === source)
            .forEach(d => dataMap.set(d.timestamp, parseFloat(d.consumption_kwh)));

        // Only add dataset if it has non-zero data
        if (dataMap.size > 0) {
            const alignedData = uniqueTimestamps.map(ts => dataMap.get(ts) || 0);
            
            datasets.push({
                label: source.charAt(0).toUpperCase() + source.slice(1),
                data: alignedData,
                color: getSourceColor(source),
                fill: source === 'solar' // Only fill solar for visual emphasis
            });
        }
    });

    return { labels, datasets };
}

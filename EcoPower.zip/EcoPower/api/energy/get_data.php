<?php

/**
 * Get Energy Data API
 * Retrieves historical energy consumption data with filtering
 */

require_once '../../config/database.php';
require_once '../../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendJsonResponse(false, 'Invalid request method');
}

// Check authentication
if (!isLoggedIn()) {
    sendJsonResponse(false, 'Authentication required');
}

if (!checkSessionTimeout()) {
    sendJsonResponse(false, 'Session expired. Please login again');
}

$user_id = getCurrentUserId();

// Get query parameters
$start_date = $_GET['start_date'] ?? null;
$end_date = $_GET['end_date'] ?? null;
$energy_source = $_GET['energy_source'] ?? null;
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 100;
$offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;

try {
    // Connect to database
    $database = new Database();
    $conn = $database->getConnection();

    if (!$conn) {
        sendJsonResponse(false, 'Database connection failed');
    }

    // Build query
    $where_clauses = ["user_id = :user_id"];
    $params = [':user_id' => $user_id];

    if ($start_date) {
        $where_clauses[] = "timestamp >= :start_date";
        $params[':start_date'] = $start_date;
    }

    if ($end_date) {
        $where_clauses[] = "timestamp <= :end_date";
        $params[':end_date'] = $end_date;
    }

    if ($energy_source && in_array($energy_source, ['grid', 'solar', 'generator'])) {
        $where_clauses[] = "energy_source = :energy_source";
        $params[':energy_source'] = $energy_source;
    }

    $where_sql = implode(' AND ', $where_clauses);

    // Get total count
    $count_stmt = $conn->prepare("SELECT COUNT(*) as total FROM energy_data WHERE $where_sql");
    foreach ($params as $key => $value) {
        $count_stmt->bindValue($key, $value);
    }
    $count_stmt->execute();
    $total = $count_stmt->fetch()['total'];

    // Get data
    $stmt = $conn->prepare("
        SELECT id, timestamp, energy_source, consumption_kwh, cost_per_kwh, notes, created_at
        FROM energy_data
        WHERE $where_sql
        ORDER BY timestamp DESC
        LIMIT :limit OFFSET :offset
    ");

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

    $stmt->execute();
    $data = $stmt->fetchAll();

    // Get summary statistics
    $summary_stmt = $conn->prepare("
        SELECT 
            energy_source,
            COUNT(*) as count,
            SUM(consumption_kwh) as total_consumption,
            AVG(consumption_kwh) as avg_consumption,
            SUM(consumption_kwh * cost_per_kwh) as total_cost
        FROM energy_data
        WHERE $where_sql
        GROUP BY energy_source
    ");

    foreach ($params as $key => $value) {
        $summary_stmt->bindValue($key, $value);
    }
    $summary_stmt->execute();
    $summary = $summary_stmt->fetchAll();

    sendJsonResponse(true, 'Data retrieved successfully', [
        'total' => $total,
        'limit' => $limit,
        'offset' => $offset,
        'data' => $data,
        'summary' => $summary
    ]);
} catch (PDOException $e) {
    error_log("Get Energy Data Error: " . $e->getMessage());
    sendJsonResponse(false, 'An error occurred while retrieving energy data');
}

<?php

/**
 * Add Energy Data API
 * Handles manual energy data entry and bulk uploads
 */

require_once '../../config/database.php';
require_once '../../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Invalid request method');
}

// Check authentication
if (!isLoggedIn()) {
    sendJsonResponse(false, 'Authentication required');
}

if (!checkSessionTimeout()) {
    sendJsonResponse(false, 'Session expired. Please login again');
}

$user_id = getCurrentUserId();

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

try {
    // Connect to database
    $database = new Database();
    $conn = $database->getConnection();

    if (!$conn) {
        sendJsonResponse(false, 'Database connection failed');
    }

    // Check if bulk upload or single entry
    if (isset($data['bulk']) && is_array($data['bulk'])) {
        // Bulk upload
        $inserted = 0;
        $errors = [];

        $stmt = $conn->prepare("
            INSERT INTO energy_data (user_id, timestamp, energy_source, consumption_kwh, cost_per_kwh, notes)
            VALUES (:user_id, :timestamp, :energy_source, :consumption_kwh, :cost_per_kwh, :notes)
        ");

        foreach ($data['bulk'] as $index => $entry) {
            try {
                // Validate required fields
                if (empty($entry['timestamp']) || empty($entry['energy_source']) || !isset($entry['consumption_kwh'])) {
                    $errors[] = "Entry $index: Missing required fields";
                    continue;
                }

                // Validate energy source
                if (!in_array($entry['energy_source'], ['grid', 'solar', 'generator'])) {
                    $errors[] = "Entry $index: Invalid energy source";
                    continue;
                }

                // Validate consumption
                if (!is_numeric($entry['consumption_kwh']) || $entry['consumption_kwh'] < 0) {
                    $errors[] = "Entry $index: Invalid consumption value";
                    continue;
                }

                // Set default cost based on source
                $cost_per_kwh = $entry['cost_per_kwh'] ?? match ($entry['energy_source']) {
                    'grid' => COST_GRID_PER_KWH,
                    'solar' => COST_SOLAR_PER_KWH,
                    'generator' => COST_GENERATOR_PER_KWH,
                    default => 0
                };

                $notes = $entry['notes'] ?? '';

                $stmt->bindParam(':user_id', $user_id);
                $stmt->bindParam(':timestamp', $entry['timestamp']);
                $stmt->bindParam(':energy_source', $entry['energy_source']);
                $stmt->bindParam(':consumption_kwh', $entry['consumption_kwh']);
                $stmt->bindParam(':cost_per_kwh', $cost_per_kwh);
                $stmt->bindParam(':notes', $notes);

                if ($stmt->execute()) {
                    $inserted++;
                }
            } catch (PDOException $e) {
                $errors[] = "Entry $index: " . $e->getMessage();
            }
        }

        sendJsonResponse(true, "Bulk upload completed", [
            'inserted' => $inserted,
            'total' => count($data['bulk']),
            'errors' => $errors
        ]);
    } else {
        // Single entry
        // Validate required fields
        if (empty($data['timestamp']) || empty($data['energy_source']) || !isset($data['consumption_kwh'])) {
            sendJsonResponse(false, 'Missing required fields: timestamp, energy_source, consumption_kwh');
        }

        // Validate energy source
        if (!in_array($data['energy_source'], ['grid', 'solar', 'generator'])) {
            sendJsonResponse(false, 'Invalid energy source. Must be: grid, solar, or generator');
        }

        // Validate consumption
        if (!is_numeric($data['consumption_kwh']) || $data['consumption_kwh'] < 0) {
            sendJsonResponse(false, 'Invalid consumption value');
        }

        // Set default cost based on source
        $cost_per_kwh = $data['cost_per_kwh'] ?? match ($data['energy_source']) {
            'grid' => COST_GRID_PER_KWH,
            'solar' => COST_SOLAR_PER_KWH,
            'generator' => COST_GENERATOR_PER_KWH,
            default => 0
        };

        $notes = $data['notes'] ?? '';

        $stmt = $conn->prepare("
            INSERT INTO energy_data (user_id, timestamp, energy_source, consumption_kwh, cost_per_kwh, notes)
            VALUES (:user_id, :timestamp, :energy_source, :consumption_kwh, :cost_per_kwh, :notes)
        ");

        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':timestamp', $data['timestamp']);
        $stmt->bindParam(':energy_source', $data['energy_source']);
        $stmt->bindParam(':consumption_kwh', $data['consumption_kwh']);
        $stmt->bindParam(':cost_per_kwh', $cost_per_kwh);
        $stmt->bindParam(':notes', $notes);

        if ($stmt->execute()) {
            sendJsonResponse(true, 'Energy data added successfully', [
                'id' => $conn->lastInsertId()
            ]);
        } else {
            sendJsonResponse(false, 'Failed to add energy data');
        }
    }
} catch (PDOException $e) {
    error_log("Add Energy Data Error: " . $e->getMessage());
    sendJsonResponse(false, 'An error occurred while adding energy data');
}

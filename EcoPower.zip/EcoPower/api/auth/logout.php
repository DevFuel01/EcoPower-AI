<?php

/**
 * User Logout API
 * Handles session termination
 */

require_once '../../config/config.php';

header('Content-Type: application/json');

// Destroy session
session_unset();
session_destroy();

sendJsonResponse(true, 'Logout successful');

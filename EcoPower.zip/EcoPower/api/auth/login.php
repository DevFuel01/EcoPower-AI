<?php

/**
 * User Login API
 * Handles user authentication and session creation
 */

require_once '../../config/database.php';
require_once '../../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Invalid request method');
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (empty($data['username']) || empty($data['password'])) {
    sendJsonResponse(false, 'Username and password are required');
}

$username = sanitizeInput($data['username']);
$password = $data['password'];

try {
    // Connect to database
    $database = new Database();
    $conn = $database->getConnection();

    if (!$conn) {
        sendJsonResponse(false, 'Database connection failed');
    }

    // Get user by username or email
    $stmt = $conn->prepare("
        SELECT id, username, email, password_hash, full_name, business_type, location
        FROM users
        WHERE username = :u_name OR email = :u_email
    ");
    $stmt->bindParam(':u_name', $username);
    $stmt->bindParam(':u_email', $username);
    $stmt->execute();

    if ($stmt->rowCount() === 0) {
        sendJsonResponse(false, 'Invalid username or password');
    }

    $user = $stmt->fetch();

    // Verify password
    if (!password_verify($password, $user['password_hash'])) {
        sendJsonResponse(false, 'Invalid username or password');
    }

    // Update last login time
    $updateStmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
    $updateStmt->bindParam(':id', $user['id']);
    $updateStmt->execute();

    // Create session
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['business_type'] = $user['business_type'];
    $_SESSION['last_activity'] = time();

    sendJsonResponse(true, 'Login successful', [
        'user_id' => $user['id'],
        'username' => $user['username'],
        'email' => $user['email'],
        'full_name' => $user['full_name'],
        'business_type' => $user['business_type'],
        'location' => $user['location']
    ]);
} catch (PDOException $e) {
    error_log("Login Error: " . $e->getMessage());
    sendJsonResponse(false, 'Login error: ' . $e->getMessage());
}

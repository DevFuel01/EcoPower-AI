<?php

/**
 * User Registration API
 * Handles new user account creation
 */

require_once '../../config/database.php';
require_once '../../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Invalid request method');
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$required = ['username', 'email', 'password', 'full_name'];
foreach ($required as $field) {
    if (empty($data[$field])) {
        sendJsonResponse(false, "Field '$field' is required");
    }
}

// Sanitize inputs
$username = sanitizeInput($data['username']);
$email = sanitizeInput($data['email']);
$password = $data['password'];
$full_name = sanitizeInput($data['full_name']);
$business_type = isset($data['business_type']) ? sanitizeInput($data['business_type']) : 'household';
$location = isset($data['location']) ? sanitizeInput($data['location']) : '';

// Validate email format
if (!isValidEmail($email)) {
    sendJsonResponse(false, 'Invalid email format');
}

// Validate username (alphanumeric and underscore only)
if (!preg_match('/^[a-zA-Z0-9_]{3,50}$/', $username)) {
    sendJsonResponse(false, 'Username must be 3-50 characters (letters, numbers, underscore only)');
}

// Validate password strength
if (strlen($password) < 6) {
    sendJsonResponse(false, 'Password must be at least 6 characters long');
}

// Validate business type
if (!in_array($business_type, ['household', 'small_business'])) {
    sendJsonResponse(false, 'Invalid business type');
}

try {
    // Connect to database
    $database = new Database();
    $conn = $database->getConnection();

    if (!$conn) {
        sendJsonResponse(false, 'Database connection failed');
    }

    // Check if username already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        sendJsonResponse(false, 'Username already exists');
    }

    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        sendJsonResponse(false, 'Email already registered');
    }

    // Hash password
    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    // Insert new user
    $stmt = $conn->prepare("
        INSERT INTO users (username, email, password_hash, full_name, business_type, location)
        VALUES (:username, :email, :password_hash, :full_name, :business_type, :location)
    ");

    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password_hash', $password_hash);
    $stmt->bindParam(':full_name', $full_name);
    $stmt->bindParam(':business_type', $business_type);
    $stmt->bindParam(':location', $location);

    if ($stmt->execute()) {
        $user_id = $conn->lastInsertId();

        sendJsonResponse(true, 'Registration successful', [
            'user_id' => $user_id,
            'username' => $username
        ]);
    } else {
        sendJsonResponse(false, 'Registration failed');
    }
} catch (PDOException $e) {
    error_log("Registration Error: " . $e->getMessage());
    sendJsonResponse(false, 'An error occurred during registration');
}

<?php

/**
 * Dashboard Summary API
 * Aggregates all key metrics for the main dashboard
 */

require_once '../../config/database.php';
require_once '../../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendJsonResponse(false, 'Invalid request method');
}

// Check authentication
if (!isLoggedIn()) {
    sendJsonResponse(false, 'Authentication required');
}

$user_id = getCurrentUserId();

try {
    $database = new Database();
    $conn = $database->getConnection();

    // 1. Get Consumption Stats (Last 30 Days)
    $stats_stmt = $conn->prepare("
        SELECT 
            energy_source,
            SUM(consumption_kwh) as total_kwh,
            COUNT(*) as readings
        FROM energy_data
        WHERE user_id = :user_id 
        AND timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY energy_source
    ");
    $stats_stmt->execute([':user_id' => $user_id]);
    $consumption_stats = $stats_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate totals and percentages
    $total_kwh = 0;
    foreach ($consumption_stats as $stat) {
        $total_kwh += floatval($stat['total_kwh']);
    }

    $source_distribution = [];
    foreach ($consumption_stats as $stat) {
        $source_distribution[$stat['energy_source']] = [
            'kwh' => round(floatval($stat['total_kwh']), 2),
            'percentage' => $total_kwh > 0 ? round((floatval($stat['total_kwh']) / $total_kwh) * 100, 1) : 0
        ];
    }

    // 2. Get Savings & Impact (All Time)
    $impact_stmt = $conn->prepare("
        SELECT 
            SUM(fuel_saved_liters) as total_fuel_saved,
            SUM(co2_reduced_kg) as total_co2_reduced,
            SUM(cost_savings) as total_cost_savings
        FROM impact_metrics
        WHERE user_id = :user_id
    ");
    $impact_stmt->execute([':user_id' => $user_id]);
    $impact = $impact_stmt->fetch(PDO::FETCH_ASSOC);

    // 3. Get Recent Recommendations (Pending)
    $rec_stmt = $conn->prepare("
        SELECT *
        FROM recommendations
        WHERE user_id = :user_id 
        AND status = 'pending'
        AND recommendation_date >= DATE(NOW())
        ORDER BY priority = 'high' DESC, recommendation_date ASC
        LIMIT 5
    ");
    $rec_stmt->execute([':user_id' => $user_id]);
    $recommendations = $rec_stmt->fetchAll(PDO::FETCH_ASSOC);

    // 4. Get Active Anomalies (Last 24 Hours)
    $anomaly_stmt = $conn->prepare("
        SELECT *
        FROM anomalies
        WHERE user_id = :user_id
        AND detected_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ORDER BY detected_at DESC
        LIMIT 3
    ");
    $anomaly_stmt->execute([':user_id' => $user_id]);
    $anomalies = $anomaly_stmt->fetchAll(PDO::FETCH_ASSOC);

    // 5. Get Recent Energy Data (Chart Data - Last 24 Hours)
    $chart_stmt = $conn->prepare("
        SELECT timestamp, energy_source, consumption_kwh
        FROM energy_data
        WHERE user_id = :user_id
        AND timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ORDER BY timestamp ASC
    ");
    $chart_stmt->execute([':user_id' => $user_id]);
    $chart_data = $chart_stmt->fetchAll(PDO::FETCH_ASSOC);

    sendJsonResponse(true, 'Dashboard data retrieved', [
        'overview' => [
            'total_consumption_30d' => round($total_kwh, 2),
            'source_distribution' => $source_distribution
        ],
        'impact' => [
            'total_fuel_saved' => round(floatval($impact['total_fuel_saved']), 2),
            'total_co2_reduced' => round(floatval($impact['total_co2_reduced']), 2),
            'total_cost_savings' => round(floatval($impact['total_cost_savings']), 2)
        ],
        'recent_recommendations' => $recommendations,
        'active_anomalies' => $anomalies,
        'chart_data' => $chart_data
    ]);
} catch (PDOException $e) {
    error_log("Dashboard API Error: " . $e->getMessage());
    sendJsonResponse(false, 'Database error: ' . $e->getMessage());
} catch (Exception $e) {
    error_log("Dashboard API Error: " . $e->getMessage());
    sendJsonResponse(false, 'An error occurred');
}

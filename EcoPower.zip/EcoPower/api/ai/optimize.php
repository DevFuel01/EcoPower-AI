<?php

/**
 * Energy Optimization Engine
 * Recommends optimal energy source based on predicted demand
 * 
 * OPTIMIZATION LOGIC:
 * 1. Analyze predicted energy demand for upcoming time windows
 * 2. Evaluate solar availability based on time of day
 * 3. Consider grid stability patterns
 * 4. Prioritize reduced generator runtime to minimize fuel consumption
 * 5. Generate actionable recommendations with clear reasoning
 */

require_once '../../config/database.php';
require_once '../../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Invalid request method');
}

// Check authentication
if (!isLoggedIn()) {
    sendJsonResponse(false, 'Authentication required');
}

if (!checkSessionTimeout()) {
    sendJsonResponse(false, 'Session expired. Please login again');
}

$user_id = getCurrentUserId();

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$optimization_date = $data['date'] ?? date('Y-m-d');

try {
    // Connect to database
    $database = new Database();
    $conn = $database->getConnection();

    if (!$conn) {
        sendJsonResponse(false, 'Database connection failed');
    }

    // ============================================
    // STEP 1: Get Predictions for Target Date
    // ============================================
    $stmt = $conn->prepare("
        SELECT 
            id,
            prediction_date,
            predicted_consumption_kwh,
            confidence_score,
            prediction_method
        FROM predictions
        WHERE user_id = :user_id
        AND DATE(prediction_date) >= :target_date
        ORDER BY prediction_date ASC
    ");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':target_date', $optimization_date);
    $stmt->execute();
    $predictions = $stmt->fetchAll();

    if (count($predictions) === 0) {
        sendJsonResponse(false, 'No predictions found for the specified date. Please generate predictions first.');
    }

    // ============================================
    // STEP 2: Analyze Current Energy Usage Patterns
    // ============================================
    // Get recent energy source usage to understand current patterns
    $pattern_stmt = $conn->prepare("
        SELECT 
            HOUR(timestamp) as hour,
            energy_source,
            AVG(consumption_kwh) as avg_consumption,
            COUNT(*) as usage_count
        FROM energy_data
        WHERE user_id = :user_id
        AND timestamp >= DATE_SUB(NOW(), INTERVAL 14 DAY)
        GROUP BY HOUR(timestamp), energy_source
    ");
    $pattern_stmt->bindParam(':user_id', $user_id);
    $pattern_stmt->execute();
    $usage_patterns = $pattern_stmt->fetchAll();

    // Build current source map by hour
    $current_sources = [];
    foreach ($usage_patterns as $pattern) {
        $hour = $pattern['hour'];
        if (!isset($current_sources[$hour])) {
            $current_sources[$hour] = [
                'source' => $pattern['energy_source'],
                'count' => $pattern['usage_count']
            ];
        } else if ($pattern['usage_count'] > $current_sources[$hour]['count']) {
            // Use most frequently used source for that hour
            $current_sources[$hour] = [
                'source' => $pattern['energy_source'],
                'count' => $pattern['usage_count']
            ];
        }
    }

    // ============================================
    // STEP 3: Generate Recommendations
    // ============================================
    $recommendations = [];
    $total_fuel_savings = 0;
    $total_cost_savings = 0;

    foreach ($predictions as $prediction) {
        $prediction_datetime = new DateTime($prediction['prediction_date']);
        $hour = intval($prediction_datetime->format('H'));
        $predicted_kwh = floatval($prediction['predicted_consumption_kwh']);

        // Determine current source for this hour
        $current_source = $current_sources[$hour]['source'] ?? 'generator';

        // ============================================
        // OPTIMIZATION DECISION LOGIC
        // ============================================

        $recommended_source = null;
        $reasoning = '';
        $priority = 'medium';
        $fuel_savings = 0;
        $cost_savings = 0;

        // Rule 1: Prioritize Solar During Peak Hours
        if ($hour >= SOLAR_START_HOUR && $hour <= SOLAR_END_HOUR) {
            // Solar is available
            if ($hour >= SOLAR_PEAK_START && $hour <= SOLAR_PEAK_END) {
                // Peak solar hours (11 AM - 2 PM)
                $recommended_source = 'solar';
                $reasoning = "Peak solar hours detected. Predicted consumption (" . number_format($predicted_kwh, 1) . " kWh) can be covered by solar capacity. ";

                if ($current_source === 'generator') {
                    $fuel_savings = $predicted_kwh * FUEL_CONSUMPTION_PER_KWH;
                    $cost_savings = ($predicted_kwh * COST_GENERATOR_PER_KWH) - ($predicted_kwh * COST_SOLAR_PER_KWH);
                    $reasoning .= "Switching from generator will save approximately " . number_format($fuel_savings, 1) . "L of fuel and reduce CO₂ emissions by " . number_format($fuel_savings * CO2_PER_LITER_DIESEL, 1) . "kg.";
                    $priority = 'high';
                } else if ($current_source === 'grid') {
                    $cost_savings = ($predicted_kwh * COST_GRID_PER_KWH) - ($predicted_kwh * COST_SOLAR_PER_KWH);
                    $reasoning .= "Switching from grid to solar will save " . number_format($cost_savings, 2) . " in energy costs.";
                    $priority = 'medium';
                } else {
                    $reasoning .= "Continue using solar for maximum sustainability.";
                    $priority = 'low';
                }
            } else {
                // Non-peak solar hours (early morning or late afternoon)
                if ($predicted_kwh < 2.0) {
                    // Low consumption - solar still viable
                    $recommended_source = 'solar';
                    $reasoning = "Solar available with low predicted consumption (" . number_format($predicted_kwh, 1) . " kWh). Solar panels can handle this load efficiently.";

                    if ($current_source === 'generator') {
                        $fuel_savings = $predicted_kwh * FUEL_CONSUMPTION_PER_KWH;
                        $cost_savings = ($predicted_kwh * COST_GENERATOR_PER_KWH) - ($predicted_kwh * COST_SOLAR_PER_KWH);
                        $reasoning .= " Avoid generator usage - save " . number_format($fuel_savings, 1) . "L fuel.";
                        $priority = 'high';
                    }
                } else {
                    // Higher consumption during non-peak solar
                    $recommended_source = 'grid';
                    $reasoning = "Moderate to high consumption (" . number_format($predicted_kwh, 1) . " kWh) during non-peak solar hours. Grid power recommended for reliability.";

                    if ($current_source === 'generator') {
                        $fuel_savings = $predicted_kwh * FUEL_CONSUMPTION_PER_KWH;
                        $cost_savings = ($predicted_kwh * COST_GENERATOR_PER_KWH) - ($predicted_kwh * COST_GRID_PER_KWH);
                        $reasoning .= " Switching from generator saves " . number_format($fuel_savings, 1) . "L fuel.";
                        $priority = 'high';
                    }
                }
            }
        } else {
            // No solar available (nighttime)

            // Rule 2: Avoid Generator During Low Consumption Periods
            if ($predicted_kwh < 1.0) {
                // Very low consumption (late night)
                $recommended_source = 'grid';
                $reasoning = "Low consumption period (" . number_format($predicted_kwh, 1) . " kWh/hour). Grid power is most cost-effective. ";

                if ($current_source === 'generator') {
                    $fuel_savings = $predicted_kwh * FUEL_CONSUMPTION_PER_KWH;
                    $cost_savings = ($predicted_kwh * COST_GENERATOR_PER_KWH) - ($predicted_kwh * COST_GRID_PER_KWH);
                    $reasoning .= "Avoid generator usage during low-demand hours - save " . number_format($fuel_savings, 1) . "L fuel.";
                    $priority = 'high';
                } else {
                    $reasoning .= "Continue using grid power.";
                    $priority = 'low';
                }
            } else if ($predicted_kwh >= 1.0 && $predicted_kwh < 2.5) {
                // Moderate consumption (evening)
                $recommended_source = 'grid';
                $reasoning = "Moderate consumption (" . number_format($predicted_kwh, 1) . " kWh). Grid power recommended for cost efficiency.";

                if ($current_source === 'generator') {
                    $fuel_savings = $predicted_kwh * FUEL_CONSUMPTION_PER_KWH;
                    $cost_savings = ($predicted_kwh * COST_GENERATOR_PER_KWH) - ($predicted_kwh * COST_GRID_PER_KWH);
                    $reasoning .= " Switching from generator saves " . number_format($fuel_savings, 1) . "L fuel and " . number_format($cost_savings, 2) . " in costs.";
                    $priority = 'medium';
                }
            } else {
                // High consumption (peak evening hours)
                // Check if grid is typically stable during this hour
                $recommended_source = 'grid';
                $reasoning = "High consumption period (" . number_format($predicted_kwh, 1) . " kWh). Grid power recommended if stable. ";

                if ($current_source === 'generator') {
                    $fuel_savings = $predicted_kwh * FUEL_CONSUMPTION_PER_KWH;
                    $cost_savings = ($predicted_kwh * COST_GENERATOR_PER_KWH) - ($predicted_kwh * COST_GRID_PER_KWH);
                    $reasoning .= "If grid is available, switch from generator to save " . number_format($fuel_savings, 1) . "L fuel.";
                    $priority = 'medium';
                } else {
                    $reasoning .= "Monitor grid stability. Use generator only if grid fails.";
                    $priority = 'low';
                }
            }
        }

        // Only create recommendation if there's a change or significant savings
        if ($recommended_source !== $current_source || $fuel_savings > 0.1) {
            $recommendations[] = [
                'prediction_date' => $prediction['prediction_date'],
                'hour' => $hour,
                'recommended_source' => $recommended_source,
                'current_source' => $current_source,
                'predicted_consumption' => $predicted_kwh,
                'fuel_savings_liters' => round($fuel_savings, 2),
                'cost_savings' => round($cost_savings, 2),
                'reasoning' => $reasoning,
                'priority' => $priority
            ];

            $total_fuel_savings += $fuel_savings;
            $total_cost_savings += $cost_savings;
        }
    }

    // ============================================
    // STEP 4: Group Recommendations by Time Windows
    // ============================================
    // Combine consecutive hours with same recommendation
    $grouped_recommendations = [];
    $current_group = null;

    foreach ($recommendations as $rec) {
        if ($current_group === null) {
            $current_group = [
                'start_hour' => $rec['hour'],
                'end_hour' => $rec['hour'],
                'recommended_source' => $rec['recommended_source'],
                'current_source' => $rec['current_source'],
                'total_consumption' => $rec['predicted_consumption'],
                'fuel_savings' => $rec['fuel_savings_liters'],
                'cost_savings' => $rec['cost_savings'],
                'reasoning' => $rec['reasoning'],
                'priority' => $rec['priority']
            ];
        } else if (
            $current_group['recommended_source'] === $rec['recommended_source'] &&
            $rec['hour'] === $current_group['end_hour'] + 1
        ) {
            // Extend current group
            $current_group['end_hour'] = $rec['hour'];
            $current_group['total_consumption'] += $rec['predicted_consumption'];
            $current_group['fuel_savings'] += $rec['fuel_savings_liters'];
            $current_group['cost_savings'] += $rec['cost_savings'];
        } else {
            // Save current group and start new one
            $grouped_recommendations[] = $current_group;
            $current_group = [
                'start_hour' => $rec['hour'],
                'end_hour' => $rec['hour'],
                'recommended_source' => $rec['recommended_source'],
                'current_source' => $rec['current_source'],
                'total_consumption' => $rec['predicted_consumption'],
                'fuel_savings' => $rec['fuel_savings_liters'],
                'cost_savings' => $rec['cost_savings'],
                'reasoning' => $rec['reasoning'],
                'priority' => $rec['priority']
            ];
        }
    }

    // Add last group
    if ($current_group !== null) {
        $grouped_recommendations[] = $current_group;
    }

    // ============================================
    // STEP 5: Store Recommendations in Database
    // ============================================
    foreach ($grouped_recommendations as $group) {
        $start_time = sprintf('%02d:00:00', $group['start_hour']);
        $end_time = sprintf('%02d:00:00', $group['end_hour']);

        $insert_stmt = $conn->prepare("
            INSERT INTO recommendations 
            (user_id, recommendation_date, time_window_start, time_window_end, recommended_source, current_source, predicted_consumption_kwh, expected_fuel_savings_liters, expected_cost_savings, reasoning, priority, status)
            VALUES 
            (:user_id, :rec_date, :start_time, :end_time, :recommended_source, :current_source, :consumption, :fuel_savings, :cost_savings, :reasoning, :priority, 'pending')
        ");

        $insert_stmt->bindParam(':user_id', $user_id);
        $insert_stmt->bindParam(':rec_date', $optimization_date);
        $insert_stmt->bindParam(':start_time', $start_time);
        $insert_stmt->bindParam(':end_time', $end_time);
        $insert_stmt->bindParam(':recommended_source', $group['recommended_source']);
        $insert_stmt->bindParam(':current_source', $group['current_source']);
        $insert_stmt->bindValue(':consumption', round($group['total_consumption'], 2));
        $insert_stmt->bindValue(':fuel_savings', round($group['fuel_savings'], 2));
        $insert_stmt->bindValue(':cost_savings', round($group['cost_savings'], 2));
        $insert_stmt->bindParam(':reasoning', $group['reasoning']);
        $insert_stmt->bindParam(':priority', $group['priority']);
        $insert_stmt->execute();
    }

    // ============================================
    // STEP 6: Return Results
    // ============================================
    sendJsonResponse(true, 'Optimization recommendations generated successfully', [
        'recommendations' => $grouped_recommendations,
        'summary' => [
            'total_recommendations' => count($grouped_recommendations),
            'total_fuel_savings_liters' => round($total_fuel_savings, 2),
            'total_cost_savings' => round($total_cost_savings, 2),
            'estimated_co2_reduction_kg' => round($total_fuel_savings * CO2_PER_LITER_DIESEL, 2),
            'optimization_date' => $optimization_date
        ],
        'ai_explanation' => [
            'methodology' => 'Recommendations based on predicted energy demand, solar availability, and cost optimization.',
            'priority_logic' => 'High priority: Switch from generator to save fuel. Medium: Cost optimization. Low: Maintain current efficient source.',
            'fuel_savings_calculation' => 'Based on ' . FUEL_CONSUMPTION_PER_KWH . 'L per kWh generator consumption rate.',
            'co2_calculation' => 'Based on ' . CO2_PER_LITER_DIESEL . 'kg CO₂ per liter of diesel fuel.'
        ]
    ]);
} catch (PDOException $e) {
    error_log("Optimization Error: " . $e->getMessage());
    sendJsonResponse(false, 'An error occurred during optimization');
} catch (Exception $e) {
    error_log("Optimization Error: " . $e->getMessage());
    sendJsonResponse(false, 'An error occurred: ' . $e->getMessage());
}

<?php

/**
 * Environmental Impact Calculator
 * Calculates fuel savings, CO₂ reduction, and cost savings
 * 
 * CALCULATION METHODOLOGY:
 * 1. Compare actual energy source usage vs. baseline (all generator)
 * 2. Calculate fuel saved based on reduced generator runtime
 * 3. Convert fuel savings to CO₂ emission reduction
 * 4. Calculate cost savings from optimized energy source selection
 */

require_once '../../config/database.php';
require_once '../../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(false, 'Invalid request method');
}

// Check authentication
if (!isLoggedIn()) {
    sendJsonResponse(false, 'Authentication required');
}

if (!checkSessionTimeout()) {
    sendJsonResponse(false, 'Session expired. Please login again');
}

$user_id = getCurrentUserId();

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);
$start_date = $data['start_date'] ?? date('Y-m-d', strtotime('-7 days'));
$end_date = $data['end_date'] ?? date('Y-m-d');

try {
    // Connect to database
    $database = new Database();
    $conn = $database->getConnection();

    if (!$conn) {
        sendJsonResponse(false, 'Database connection failed');
    }

    // ============================================
    // STEP 1: Get Energy Usage Data for Period
    // ============================================
    $stmt = $conn->prepare("
        SELECT 
            energy_source,
            SUM(consumption_kwh) as total_consumption,
            COUNT(*) as reading_count,
            SUM(consumption_kwh * cost_per_kwh) as total_cost
        FROM energy_data
        WHERE user_id = :user_id
        AND DATE(timestamp) BETWEEN :start_date AND :end_date
        GROUP BY energy_source
    ");
    $stmt->bindParam(':user_id', $user_id);
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
    $stmt->execute();
    $energy_usage = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($energy_usage) === 0) {
        sendJsonResponse(false, 'No energy data found for the specified period');
    }

    // ============================================
    // STEP 2: Calculate Consumption by Source
    // ============================================
    $consumption_by_source = [
        'grid' => 0,
        'solar' => 0,
        'generator' => 0
    ];

    $cost_by_source = [
        'grid' => 0,
        'solar' => 0,
        'generator' => 0
    ];

    $total_consumption = 0;
    $actual_total_cost = 0;

    foreach ($energy_usage as $usage) {
        $source = $usage['energy_source'];
        $consumption = floatval($usage['total_consumption']);
        $cost = floatval($usage['total_cost']);

        $consumption_by_source[$source] = $consumption;
        $cost_by_source[$source] = $cost;
        $total_consumption += $consumption;
        $actual_total_cost += $cost;
    }

    // ============================================
    // STEP 3: Calculate Baseline (All Generator)
    // ============================================
    // Baseline scenario: What if all energy came from generator?
    $baseline_fuel_consumption = $total_consumption * FUEL_CONSUMPTION_PER_KWH;
    $baseline_co2_emissions = $baseline_fuel_consumption * CO2_PER_LITER_DIESEL;
    $baseline_cost = $total_consumption * COST_GENERATOR_PER_KWH;

    // ============================================
    // STEP 4: Calculate Actual Impact
    // ============================================
    // Actual fuel consumption (only from generator usage)
    $actual_fuel_consumption = $consumption_by_source['generator'] * FUEL_CONSUMPTION_PER_KWH;
    $actual_co2_emissions = $actual_fuel_consumption * CO2_PER_LITER_DIESEL;

    // ============================================
    // STEP 5: Calculate Savings
    // ============================================
    $fuel_saved_liters = $baseline_fuel_consumption - $actual_fuel_consumption;
    $co2_reduced_kg = $baseline_co2_emissions - $actual_co2_emissions;
    $cost_savings = $baseline_cost - $actual_total_cost;

    // Calculate generator hours avoided
    // Assuming average generator output of 3 kW
    $avg_generator_output_kw = 3.0;
    $generator_hours_used = $consumption_by_source['generator'] / $avg_generator_output_kw;
    $baseline_generator_hours = $total_consumption / $avg_generator_output_kw;
    $generator_hours_avoided = $baseline_generator_hours - $generator_hours_used;

    // Calculate usage percentages
    $solar_percentage = $total_consumption > 0 ? ($consumption_by_source['solar'] / $total_consumption) * 100 : 0;
    $grid_percentage = $total_consumption > 0 ? ($consumption_by_source['grid'] / $total_consumption) * 100 : 0;
    $generator_percentage = $total_consumption > 0 ? ($consumption_by_source['generator'] / $total_consumption) * 100 : 0;

    // ============================================
    // STEP 6: Store Impact Metrics
    // ============================================
    $insert_stmt = $conn->prepare("
        INSERT INTO impact_metrics 
        (user_id, calculation_date, period_start, period_end, fuel_saved_liters, co2_reduced_kg, cost_savings, generator_hours_avoided, solar_usage_percentage, grid_usage_percentage, generator_usage_percentage)
        VALUES 
        (:user_id, NOW(), :start_date, :end_date, :fuel_saved, :co2_reduced, :cost_savings, :gen_hours_avoided, :solar_pct, :grid_pct, :gen_pct)
        ON DUPLICATE KEY UPDATE
        fuel_saved_liters = VALUES(fuel_saved_liters),
        co2_reduced_kg = VALUES(co2_reduced_kg),
        cost_savings = VALUES(cost_savings),
        generator_hours_avoided = VALUES(generator_hours_avoided),
        solar_usage_percentage = VALUES(solar_usage_percentage),
        grid_usage_percentage = VALUES(grid_usage_percentage),
        generator_usage_percentage = VALUES(generator_usage_percentage)
    ");

    $insert_stmt->bindParam(':user_id', $user_id);
    $insert_stmt->bindParam(':start_date', $start_date);
    $insert_stmt->bindParam(':end_date', $end_date);
    $insert_stmt->bindValue(':fuel_saved', round($fuel_saved_liters, 2));
    $insert_stmt->bindValue(':co2_reduced', round($co2_reduced_kg, 2));
    $insert_stmt->bindValue(':cost_savings', round($cost_savings, 2));
    $insert_stmt->bindValue(':gen_hours_avoided', round($generator_hours_avoided, 2));
    $insert_stmt->bindValue(':solar_pct', round($solar_percentage, 2));
    $insert_stmt->bindValue(':grid_pct', round($grid_percentage, 2));
    $insert_stmt->bindValue(':gen_pct', round($generator_percentage, 2));
    $insert_stmt->execute();

    // ============================================
    // STEP 7: Calculate Additional Metrics
    // ============================================
    // Equivalent metrics for better understanding
    $trees_equivalent = $co2_reduced_kg / 21; // Average tree absorbs ~21kg CO2/year
    $car_km_equivalent = $co2_reduced_kg / 0.12; // Average car emits ~0.12kg CO2/km

    // ============================================
    // STEP 8: Return Results
    // ============================================
    sendJsonResponse(true, 'Environmental impact calculated successfully', [
        'period' => [
            'start_date' => $start_date,
            'end_date' => $end_date,
            'days' => (strtotime($end_date) - strtotime($start_date)) / 86400 + 1
        ],
        'consumption' => [
            'total_kwh' => round($total_consumption, 2),
            'solar_kwh' => round($consumption_by_source['solar'], 2),
            'grid_kwh' => round($consumption_by_source['grid'], 2),
            'generator_kwh' => round($consumption_by_source['generator'], 2),
            'solar_percentage' => round($solar_percentage, 1),
            'grid_percentage' => round($grid_percentage, 1),
            'generator_percentage' => round($generator_percentage, 1)
        ],
        'savings' => [
            'fuel_saved_liters' => round($fuel_saved_liters, 2),
            'co2_reduced_kg' => round($co2_reduced_kg, 2),
            'cost_savings' => round($cost_savings, 2),
            'generator_hours_avoided' => round($generator_hours_avoided, 2)
        ],
        'baseline_comparison' => [
            'baseline_fuel_liters' => round($baseline_fuel_consumption, 2),
            'actual_fuel_liters' => round($actual_fuel_consumption, 2),
            'baseline_co2_kg' => round($baseline_co2_emissions, 2),
            'actual_co2_kg' => round($actual_co2_emissions, 2),
            'baseline_cost' => round($baseline_cost, 2),
            'actual_cost' => round($actual_total_cost, 2)
        ],
        'equivalents' => [
            'trees_planted_equivalent' => round($trees_equivalent, 1),
            'car_kilometers_avoided' => round($car_km_equivalent, 1),
            'description' => "Your CO₂ reduction is equivalent to planting " . round($trees_equivalent, 1) . " trees or avoiding " . round($car_km_equivalent, 1) . " km of car travel."
        ],
        'calculation_methodology' => [
            'fuel_consumption_rate' => FUEL_CONSUMPTION_PER_KWH . ' liters per kWh',
            'co2_emission_factor' => CO2_PER_LITER_DIESEL . ' kg CO₂ per liter diesel',
            'baseline_scenario' => 'All energy from generator (worst case)',
            'savings_calculation' => 'Difference between baseline and actual usage',
            'assumptions' => [
                'Average generator output: 3 kW',
                'Generator fuel: Diesel',
                'Solar panels: No emissions',
                'Grid power: Minimal emissions (not calculated)'
            ]
        ]
    ]);
} catch (PDOException $e) {
    error_log("Impact Calculation Error: " . $e->getMessage());
    sendJsonResponse(false, 'An error occurred during impact calculation');
} catch (Exception $e) {
    error_log("Impact Calculation Error: " . $e->getMessage());
    sendJsonResponse(false, 'An error occurred: ' . $e->getMessage());
}

<?php

/**
 * Get Recommendations API
 * Retrieves optimization recommendations with summary statistics
 */

require_once '../../config/database.php';
require_once '../../config/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    sendJsonResponse(false, 'Invalid request method');
}

if (!isLoggedIn()) {
    sendJsonResponse(false, 'Authentication required');
}

$user_id = getCurrentUserId();
$date = $_GET['date'] ?? date('Y-m-d');

try {
    $database = new Database();
    $conn = $database->getConnection();

    // Fetch recommendations for the target date (or future)
    // We look for recommendations valid for today onwards
    $stmt = $conn->prepare("
        SELECT *
        FROM recommendations
        WHERE user_id = :user_id
        AND DATE(recommendation_date) >= :target_date
        ORDER BY recommendation_date ASC, time_window_start ASC
    ");
    $stmt->execute([
        ':user_id' => $user_id,
        ':target_date' => $date
    ]);

    $recommendations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate Summary Stats
    $total_recs = count($recommendations);
    $total_fuel = 0;
    $total_cost = 0;
    $total_co2 = 0; // Derived from fuel

    foreach ($recommendations as $rec) {
        $total_fuel += floatval($rec['expected_fuel_savings_liters']);
        $total_cost += floatval($rec['expected_cost_savings']);

        // Comprehensive CO2 calculation
        $fuel_co2 = floatval($rec['expected_fuel_savings_liters']) * CO2_PER_LITER_DIESEL;

        // Add Grid CO2 savings if switching from grid to solar
        $grid_co2 = 0;
        if ($rec['current_source'] === 'grid' && $rec['recommended_source'] === 'solar') {
            $grid_co2 = floatval($rec['predicted_consumption_kwh']) * CO2_PER_KWH_GRID;
        }

        $total_co2 += ($fuel_co2 + $grid_co2);
    }

    sendJsonResponse(true, 'Recommendations retrieved', [
        'recommendations' => $recommendations,
        'summary' => [
            'total_recommendations' => $total_recs,
            'potential_fuel_savings_liters' => round($total_fuel, 2),
            'potential_cost_savings' => round($total_cost, 2),
            'potential_co2_reduction_kg' => round($total_co2, 2)
        ]
    ]);
} catch (PDOException $e) {
    error_log("Get Recommendations Error: " . $e->getMessage());
    sendJsonResponse(false, 'Database error');
}

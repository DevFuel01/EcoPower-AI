<?php
// Trigger Impact Calculation
require_once '../../config/config.php';

echo "Triggering Impact Calculation...\n";

$url = 'http://localhost/EcoPower/api/ai/calculate_impact.php';

// Prepare data for last 30 days
$data = [
    'start_date' => date('Y-m-d', strtotime('-30 days')),
    'end_date' => date('Y-m-d')
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Cookie: PHPSESSID=' . $_COOKIE['PHPSESSID'] // Pass current session
]);

// Handle session if run from CLI (won't work for auth-protected endpoint without valid session)
// Since we can't easily fake the session cookie from CLI without knowing it, 
// we will assume the user has to run this via browser or we modify the endpoint to allow a secret key for internal triggering.
// However, since we are logged in as the user in the browser context, maybe we can just use a JS fetch in the console?
// Or we can modify calculate_impact.php temporarily to bypass auth for CLI? No, that's insecure.

// Better approach: Create a temporary HTML page that does the fetch for us, since we are in a browser context.
?>
<h1>Running Impact Calculation...</h1>
<script>
    fetch('/EcoPower/api/ai/calculate_impact.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                start_date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                end_date: new Date().toISOString().split('T')[0]
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Success:', data);
            document.body.innerHTML += '<p>Calculation Complete! <a href="../../dashboard.html">Return to Dashboard</a></p>';
            setTimeout(() => window.location.href = '../../dashboard.html', 2000);
        })
        .catch((error) => {
            console.error('Error:', error);
            document.body.innerHTML += '<p style="color:red">Error: ' + error + '</p>';
        });
</script>
<?php

/**
 * Seed Data Script
 * Generates realistic sample data for the current user
 */

require_once '../../config/database.php';
require_once '../../config/config.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    die("Please login first.");
}

$user_id = $_SESSION['user_id'];

try {
    $database = new Database();
    $conn = $database->getConnection();

    // Clear existing data for this user to avoid duplicates/conflicts
    $stmt = $conn->prepare("DELETE FROM energy_data WHERE user_id = :user_id");
    $stmt->execute([':user_id' => $user_id]);

    // Generate 30 days of data
    $records_inserted = 0;

    $stmt = $conn->prepare("
        INSERT INTO energy_data (user_id, energy_source, consumption_kwh, cost_per_kwh, timestamp)
        VALUES (:user_id, :source, :kwh, :cost, :time)
    ");

    for ($d = 30; $d >= 0; $d--) {
        $date = date('Y-m-d', strtotime("-$d days"));

        // Generate for each hour
        for ($h = 0; $h < 24; $h++) {
            $time = "$date " . str_pad($h, 2, '0', STR_PAD_LEFT) . ":00:00";

            // Simulation Logic
            $is_sunny = ($h >= 8 && $h <= 16);
            $is_peak = ($h >= 18 && $h <= 22);

            // Solar
            if ($is_sunny) {
                // Solar generates power, effectively reducing grid demand or being recorded as solar consumption/generation
                // For simplicity in this model, we record 'solar' as a source used
                $solar_kwh = rand(20, 50) / 10; // 2.0 - 5.0 kWh
                $stmt->execute([
                    ':user_id' => $user_id,
                    ':source' => 'solar',
                    ':kwh' => $solar_kwh,
                    ':cost' => 0.00,
                    ':time' => $time
                ]);
                $records_inserted++;
            }

            // Grid
            $grid_kwh = rand(10, 30) / 10; // 1.0 - 3.0 kWh base
            if ($is_peak) $grid_kwh += rand(20, 40) / 10; // Peak load

            $stmt->execute([
                ':user_id' => $user_id,
                ':source' => 'grid',
                ':kwh' => $grid_kwh,
                ':cost' => 0.15,
                ':time' => $time
            ]);
            $records_inserted++;

            // Generator (occasional use during peak)
            if ($is_peak && rand(0, 10) > 7) {
                $gen_kwh = rand(30, 60) / 10;
                $stmt->execute([
                    ':user_id' => $user_id,
                    ':source' => 'generator',
                    ':kwh' => $gen_kwh,
                    ':cost' => 0.50, // Higher cost
                    ':time' => $time
                ]);
                $records_inserted++;
            }
        }
    }

    echo "<h1>Data Seeded Successfully!</h1>";
    echo "<p>Inserted $records_inserted records for user ID $user_id.</p>";
    echo "<p><a href='../../analysis.html'>Return to Analysis</a></p>";
    echo "<script>setTimeout(() => window.location.href = '../../analysis.html', 3000);</script>";
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

-- ============================================
-- EcoPower AI - Database Schema
-- ============================================
-- AI-powered energy optimization platform
-- Helps reduce generator fuel consumption and carbon emissions
-- ============================================

-- Create database
CREATE DATABASE IF NOT EXISTS ecopower_ai;
USE ecopower_ai;

-- ============================================
-- Table: users
-- Stores user authentication and profile data
-- ============================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    business_type ENUM('household', 'small_business') DEFAULT 'household',
    location VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_email (email),
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Table: energy_data
-- Stores historical energy consumption records
-- ============================================
CREATE TABLE energy_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    timestamp DATETIME NOT NULL,
    energy_source ENUM('grid', 'solar', 'generator') NOT NULL,
    consumption_kwh DECIMAL(10, 2) NOT NULL,
    cost_per_kwh DECIMAL(10, 2) DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_timestamp (user_id, timestamp),
    INDEX idx_source (energy_source)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Table: predictions
-- Stores AI-generated demand forecasts
-- ============================================
CREATE TABLE predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    prediction_date DATETIME NOT NULL,
    predicted_consumption_kwh DECIMAL(10, 2) NOT NULL,
    confidence_score DECIMAL(5, 2) NOT NULL COMMENT 'Confidence percentage (0-100)',
    prediction_method VARCHAR(50) NOT NULL COMMENT 'e.g., moving_average, trend_analysis',
    time_window VARCHAR(20) NOT NULL COMMENT 'e.g., hourly, daily',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_date (user_id, prediction_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Table: recommendations
-- Stores optimization suggestions
-- ============================================
CREATE TABLE recommendations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    recommendation_date DATETIME NOT NULL,
    time_window_start TIME NOT NULL,
    time_window_end TIME NOT NULL,
    recommended_source ENUM('grid', 'solar', 'generator') NOT NULL,
    current_source ENUM('grid', 'solar', 'generator'),
    predicted_consumption_kwh DECIMAL(10, 2) DEFAULT 0,
    expected_fuel_savings_liters DECIMAL(10, 2) DEFAULT 0,
    expected_cost_savings DECIMAL(10, 2) DEFAULT 0,
    reasoning TEXT NOT NULL COMMENT 'AI explanation for recommendation',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    status ENUM('pending', 'applied', 'ignored') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_date (user_id, recommendation_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Table: impact_metrics
-- Tracks environmental impact and savings
-- ============================================
CREATE TABLE impact_metrics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    calculation_date DATE NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    fuel_saved_liters DECIMAL(10, 2) NOT NULL DEFAULT 0,
    co2_reduced_kg DECIMAL(10, 2) NOT NULL DEFAULT 0 COMMENT 'CO2 emissions avoided',
    cost_savings DECIMAL(10, 2) NOT NULL DEFAULT 0,
    generator_hours_avoided DECIMAL(10, 2) DEFAULT 0,
    solar_usage_percentage DECIMAL(5, 2) DEFAULT 0,
    grid_usage_percentage DECIMAL(5, 2) DEFAULT 0,
    generator_usage_percentage DECIMAL(5, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_period (user_id, period_start, period_end),
    UNIQUE KEY unique_user_calculation (user_id, calculation_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Table: anomalies
-- Stores detected energy consumption anomalies
-- ============================================
CREATE TABLE anomalies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    energy_data_id INT NOT NULL,
    detected_at DATETIME NOT NULL,
    anomaly_type VARCHAR(50) NOT NULL COMMENT 'e.g., spike, unusual_pattern',
    severity ENUM('low', 'medium', 'high') DEFAULT 'medium',
    expected_consumption_kwh DECIMAL(10, 2) NOT NULL,
    actual_consumption_kwh DECIMAL(10, 2) NOT NULL,
    deviation_percentage DECIMAL(5, 2) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (energy_data_id) REFERENCES energy_data(id) ON DELETE CASCADE,
    INDEX idx_user_detected (user_id, detected_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Sample Data for Demo
-- ============================================

-- Insert demo user
INSERT INTO users (username, email, password_hash, full_name, business_type, location) VALUES
('demo_user', 'demo@ecopower.ai', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Demo User', 'household', 'Lagos, Nigeria'),
('business_demo', 'business@ecopower.ai', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Small Business Demo', 'small_business', 'Accra, Ghana'),
('ibrahim', 'ibrahim@ecopower.ai', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Ibrahim Idris', 'small_business', 'Kano, Nigeria');

-- Insert 30 days of hourly energy consumption data for demo_user (user_id = 1)
-- Simulating realistic patterns: solar during day, grid in evening, generator during outages

-- Day 1-5: Typical week with mixed sources
INSERT INTO energy_data (user_id, timestamp, energy_source, consumption_kwh, cost_per_kwh) VALUES
-- Day 1 (Monday) - Grid morning, Solar afternoon, Generator evening
(1, '2026-01-01 00:00:00', 'grid', 0.8, 0.15),
(1, '2026-01-01 01:00:00', 'grid', 0.6, 0.15),
(1, '2026-01-01 02:00:00', 'grid', 0.5, 0.15),
(1, '2026-01-01 03:00:00', 'grid', 0.5, 0.15),
(1, '2026-01-01 04:00:00', 'grid', 0.5, 0.15),
(1, '2026-01-01 05:00:00', 'grid', 0.7, 0.15),
(1, '2026-01-01 06:00:00', 'grid', 1.2, 0.15),
(1, '2026-01-01 07:00:00', 'grid', 1.5, 0.15),
(1, '2026-01-01 08:00:00', 'solar', 1.8, 0.05),
(1, '2026-01-01 09:00:00', 'solar', 2.2, 0.05),
(1, '2026-01-01 10:00:00', 'solar', 2.5, 0.05),
(1, '2026-01-01 11:00:00', 'solar', 2.8, 0.05),
(1, '2026-01-01 12:00:00', 'solar', 3.0, 0.05),
(1, '2026-01-01 13:00:00', 'solar', 2.9, 0.05),
(1, '2026-01-01 14:00:00', 'solar', 2.7, 0.05),
(1, '2026-01-01 15:00:00', 'solar', 2.3, 0.05),
(1, '2026-01-01 16:00:00', 'solar', 1.8, 0.05),
(1, '2026-01-01 17:00:00', 'grid', 1.5, 0.15),
(1, '2026-01-01 18:00:00', 'generator', 2.5, 0.35),
(1, '2026-01-01 19:00:00', 'generator', 3.2, 0.35),
(1, '2026-01-01 20:00:00', 'generator', 2.8, 0.35),
(1, '2026-01-01 21:00:00', 'grid', 2.0, 0.15),
(1, '2026-01-01 22:00:00', 'grid', 1.5, 0.15),
(1, '2026-01-01 23:00:00', 'grid', 1.0, 0.15);

-- Day 2 (Tuesday) - More solar usage
INSERT INTO energy_data (user_id, timestamp, energy_source, consumption_kwh, cost_per_kwh) VALUES
(1, '2026-01-02 08:00:00', 'solar', 1.9, 0.05),
(1, '2026-01-02 09:00:00', 'solar', 2.3, 0.05),
(1, '2026-01-02 10:00:00', 'solar', 2.6, 0.05),
(1, '2026-01-02 11:00:00', 'solar', 2.9, 0.05),
(1, '2026-01-02 12:00:00', 'solar', 3.1, 0.05),
(1, '2026-01-02 13:00:00', 'solar', 3.0, 0.05),
(1, '2026-01-02 14:00:00', 'solar', 2.8, 0.05),
(1, '2026-01-02 15:00:00', 'solar', 2.4, 0.05),
(1, '2026-01-02 16:00:00', 'solar', 1.9, 0.05),
(1, '2026-01-02 17:00:00', 'solar', 1.2, 0.05),
(1, '2026-01-02 18:00:00', 'grid', 2.0, 0.15),
(1, '2026-01-02 19:00:00', 'grid', 2.8, 0.15),
(1, '2026-01-02 20:00:00', 'grid', 2.5, 0.15),
(1, '2026-01-02 21:00:00', 'grid', 1.8, 0.15),
(1, '2026-01-02 22:00:00', 'grid', 1.3, 0.15);

-- Day 3 (Wednesday) - Grid outage, heavy generator use
INSERT INTO energy_data (user_id, timestamp, energy_source, consumption_kwh, cost_per_kwh) VALUES
(1, '2026-01-03 06:00:00', 'generator', 1.5, 0.35),
(1, '2026-01-03 07:00:00', 'generator', 2.0, 0.35),
(1, '2026-01-03 08:00:00', 'solar', 2.0, 0.05),
(1, '2026-01-03 09:00:00', 'solar', 2.4, 0.05),
(1, '2026-01-03 10:00:00', 'solar', 2.7, 0.05),
(1, '2026-01-03 11:00:00', 'solar', 3.0, 0.05),
(1, '2026-01-03 12:00:00', 'solar', 3.2, 0.05),
(1, '2026-01-03 13:00:00', 'solar', 3.1, 0.05),
(1, '2026-01-03 14:00:00', 'solar', 2.9, 0.05),
(1, '2026-01-03 15:00:00', 'solar', 2.5, 0.05),
(1, '2026-01-03 16:00:00', 'solar', 2.0, 0.05),
(1, '2026-01-03 17:00:00', 'generator', 2.2, 0.35),
(1, '2026-01-03 18:00:00', 'generator', 3.0, 0.35),
(1, '2026-01-03 19:00:00', 'generator', 3.5, 0.35),
(1, '2026-01-03 20:00:00', 'generator', 3.2, 0.35),
(1, '2026-01-03 21:00:00', 'generator', 2.5, 0.35),
(1, '2026-01-03 22:00:00', 'generator', 1.8, 0.35);

-- Add more varied data for Days 4-7
INSERT INTO energy_data (user_id, timestamp, energy_source, consumption_kwh, cost_per_kwh) VALUES
-- Day 4 - Optimal solar usage
(1, '2026-01-04 08:00:00', 'solar', 2.1, 0.05),
(1, '2026-01-04 12:00:00', 'solar', 3.3, 0.05),
(1, '2026-01-04 16:00:00', 'solar', 2.0, 0.05),
(1, '2026-01-04 19:00:00', 'grid', 2.9, 0.15),
(1, '2026-01-04 22:00:00', 'grid', 1.4, 0.15),
-- Day 5 - Mixed usage
(1, '2026-01-05 09:00:00', 'solar', 2.5, 0.05),
(1, '2026-01-05 13:00:00', 'solar', 3.2, 0.05),
(1, '2026-01-05 18:00:00', 'generator', 2.7, 0.35),
(1, '2026-01-05 21:00:00', 'grid', 2.0, 0.15);

-- Sample predictions (AI-generated forecasts)
INSERT INTO predictions (user_id, prediction_date, predicted_consumption_kwh, confidence_score, prediction_method, time_window) VALUES
(1, '2026-01-19 09:00:00', 2.3, 85.5, 'moving_average', 'hourly'),
(1, '2026-01-19 12:00:00', 3.1, 88.2, 'moving_average', 'hourly'),
(1, '2026-01-19 15:00:00', 2.6, 86.0, 'trend_analysis', 'hourly'),
(1, '2026-01-19 18:00:00', 2.8, 82.3, 'time_based', 'hourly'),
(1, '2026-01-19 21:00:00', 2.1, 84.7, 'moving_average', 'hourly'),
(1, '2026-01-20 00:00:00', 25.5, 79.5, 'trend_analysis', 'daily');

-- Sample recommendations
INSERT INTO recommendations (user_id, recommendation_date, time_window_start, time_window_end, recommended_source, current_source, expected_fuel_savings_liters, expected_cost_savings, reasoning, priority, status) VALUES
(1, '2026-01-19', '08:00:00', '17:00:00', 'solar', 'generator', 4.5, 12.50, 'Peak solar hours detected. Predicted consumption (2.3-3.1 kWh) can be fully covered by solar capacity. Switching from generator will save approximately 4.5L of fuel and reduce CO₂ emissions by 12kg.', 'high', 'pending'),
(1, '2026-01-19', '18:00:00', '21:00:00', 'grid', 'generator', 2.8, 7.80, 'Grid stability detected during evening hours. Predicted moderate consumption (2.8 kWh). Grid power is more cost-effective than generator during this period.', 'medium', 'pending'),
(1, '2026-01-19', '22:00:00', '06:00:00', 'grid', 'grid', 0, 0, 'Low consumption period (0.5-0.8 kWh/hour). Continue using grid power. Avoid generator usage during low-demand hours.', 'low', 'applied');

-- Sample impact metrics
INSERT INTO impact_metrics (user_id, calculation_date, period_start, period_end, fuel_saved_liters, co2_reduced_kg, cost_savings, generator_hours_avoided, solar_usage_percentage, grid_usage_percentage, generator_usage_percentage) VALUES
(1, '2026-01-07', '2026-01-01', '2026-01-07', 28.5, 76.38, 245.50, 15.5, 45.2, 38.5, 16.3),
(1, '2026-01-14', '2026-01-08', '2026-01-14', 32.1, 86.03, 278.90, 17.2, 48.7, 35.8, 15.5),
(1, '2026-01-18', '2026-01-15', '2026-01-18', 18.3, 49.04, 158.70, 9.8, 50.1, 34.2, 15.7);

-- Sample anomalies
INSERT INTO anomalies (user_id, energy_data_id, detected_at, anomaly_type, severity, expected_consumption_kwh, actual_consumption_kwh, deviation_percentage, description) VALUES
(1, 19, '2026-01-01 19:00:00', 'consumption_spike', 'medium', 2.0, 3.2, 60.0, 'Unusual consumption spike detected. Actual usage (3.2 kWh) exceeded predicted consumption (2.0 kWh) by 60%. Possible cause: additional appliances running simultaneously.');

-- ============================================
-- Views for easier data access
-- ============================================

-- View: Daily energy summary
CREATE VIEW daily_energy_summary AS
SELECT 
    user_id,
    DATE(timestamp) as date,
    energy_source,
    SUM(consumption_kwh) as total_consumption_kwh,
    AVG(consumption_kwh) as avg_consumption_kwh,
    COUNT(*) as reading_count
FROM energy_data
GROUP BY user_id, DATE(timestamp), energy_source;

-- View: User impact overview
CREATE VIEW user_impact_overview AS
SELECT 
    u.id as user_id,
    u.username,
    u.full_name,
    SUM(im.fuel_saved_liters) as total_fuel_saved,
    SUM(im.co2_reduced_kg) as total_co2_reduced,
    SUM(im.cost_savings) as total_cost_savings,
    AVG(im.solar_usage_percentage) as avg_solar_usage
FROM users u
LEFT JOIN impact_metrics im ON u.id = im.user_id
GROUP BY u.id;

-- ============================================
-- End of Schema
-- ============================================
